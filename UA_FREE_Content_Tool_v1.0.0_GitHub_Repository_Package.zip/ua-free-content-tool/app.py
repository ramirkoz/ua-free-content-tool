from content_agent.main import main


if __name__ == "__main__":
    raise SystemExit(main())
