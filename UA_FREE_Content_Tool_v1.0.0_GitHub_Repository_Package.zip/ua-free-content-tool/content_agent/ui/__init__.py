"""Tkinter user interface."""
