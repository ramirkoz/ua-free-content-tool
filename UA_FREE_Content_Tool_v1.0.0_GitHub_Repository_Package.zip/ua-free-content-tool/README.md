# UA FREE Content Tool

**Privacy-first Windows desktop software for collecting, grouping, rewriting, scheduling and cross-posting Ukrainian news with a local Ollama model.**

UA FREE Content Tool helps a human editor collect materials from configured sources, manually group reports about the same event, prepare one concise Ukrainian publication, attach media from Google Drive and publish to Facebook Pages, Threads, LinkedIn and Telegram.

[Українська документація](README_UA.md) · [English documentation](README_EN.md) · [Platform setup](PLATFORM_SETUP_UA.md) · [Security notes](SECURITY_NOTES_UA.md)

> Public release: **v1.0.0**  
> Internal validated build: **R8 FIX30**  
> Platform: **Windows portable**  
> Interface language: **Ukrainian**

## What the application does

- Collects current news from configured RSS, Telegram and other supported sources.
- Keeps incoming materials as separate blocks until the editor decides to merge them.
- Supports manual multi-selection and manual merging of related reports.
- Provides **Find everything on this topic** to highlight possible matches without merging automatically.
- Uses all materials in a block to prepare one grounded Ukrainian rewrite.
- Produces one canonical publication of up to 900 characters with maximum factual density and minimum filler.
- Uses local Ollama models, so the source text is not sent to a paid cloud LLM by the application itself.
- Publishes to Facebook Pages, Threads, LinkedIn and Telegram.
- Uses Google Drive as the media source and can remove the file after all selected publications succeed.
- Stores sources, settings, editorial memory, exclusions and the publication queue in the portable `Data` folder.
- Supports partial retry without reposting targets that already succeeded.

## One text for every platform

The editor works with one final text.

- Facebook: one media post.
- LinkedIn: one media post.
- Telegram: media with one caption, validated against the platform caption limit.
- Threads: one post for short text; longer text is published as a main post plus replies without silently dropping content.

The application rejects English, Russian or speculative model output instead of quietly placing it into the queue.

## Requirements

### For the ready Windows build

- Windows 10 or Windows 11.
- Ollama installed locally.
- At least one compatible local model configured in the application.
- Credentials for the platforms you intend to use.
- A Google Cloud OAuth Desktop client when Google Drive media is enabled.

### For development from source

- Python 3.11–3.13.
- Dependencies from `requirements.txt` and `requirements-test.txt`.

## Quick start

1. Open the latest GitHub Release.
2. Download the Windows portable ZIP.
3. Extract the entire folder. Do not run the EXE from inside the ZIP.
4. Install Ollama and the selected model.
5. Start `UA_FREE_Content_Tool.exe` without administrator rights.
6. Open **Settings**, configure sources and platform credentials, then verify every connection.
7. Keep the whole application folder together. The EXE alone is not a portable installation.

Detailed platform steps are in [PLATFORM_SETUP_UA.md](PLATFORM_SETUP_UA.md).

## Portable data and backups

The working state lives in the `Data` folder next to the EXE. It includes the SQLite database, encrypted configuration, sources, editorial memory, exclusions and queue status.

Before every update:

1. Close the application.
2. Confirm that no `UA_FREE_Content_Tool.exe` process remains.
3. Copy the entire application folder to a backup location.
4. Apply only the documented program update.
5. Keep the previous working copy until the first successful live publication with the new version.

Never publish or upload a working `Data` folder. It may contain encrypted platform credentials and the portable encryption key.

## Privacy and security principles

- No built-in telemetry or remote usage reporting.
- Platform secrets are not stored in the public source tree or SQLite database.
- Portable secrets are encrypted locally.
- The application does not require administrator rights.
- Automatic connection diagnostics are read-only.
- Publication targets are processed sequentially and successful targets are not repeated during a partial retry.
- Google Drive permissions are changed only when required for Threads media delivery and are reverted after use.

Read the full security boundaries in [SECURITY_NOTES_UA.md](SECURITY_NOTES_UA.md).

## Release verification

The v1.0.0 source corresponds to internal build R8 FIX30. Its Windows Gate completed with:

- 223 automated tests passed;
- package-relative entrypoint imports passed;
- local smoke test passed;
- Windows portable build passed;
- clean portable startup passed;
- queue and schema preservation checks passed;
- Shift multi-selection and grounded Ukrainian rewrite guards passed.

The detailed report is stored in `docs/validation/WINDOWS_GATE_REPORT_R8_FIX30.txt`.

## Build the Windows portable package

Run from a normal Command Prompt:

```bat
Build_Portable_Windows.bat
```

The build script creates a dedicated environment, runs the validation suite and produces the portable folder under `Release`.

## Report a problem

Open a GitHub issue and include:

- application version;
- Windows version;
- Ollama model name;
- exact steps to reproduce;
- expected result;
- actual result;
- relevant log excerpt with tokens and personal data removed.

Do not post access tokens, client secrets, refresh tokens, private Google Drive links or a real `Data` folder.

## Support the UA FREE foundation

- [Donate to UA FREE](https://uafree.org/donate/)
- [Learn about the foundation](https://uafree.org/)

## Support development

Developer donations are separate from donations to the UA FREE charitable foundation.

- **PayPal:** `kozyriev@uafree.org`
- [Donate via PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=kozyriev%40uafree.org&item_name=Support+UA+FREE+Content+Tool+development&currency_code=USD)
- **BTC:** `bc1q4dn8e7sz2866g7qp1qtshh98j54tvuau5ghuuk`
- **ETH / USDC ERC-20:** `0x3aE3b23A7BD94b8a65A7E8Ca205A4e29BEF7c229`
- **USDT TRC-20:** `TYsGyK7K3XB4NPHprf5w8ZodFafxFfDdbP`

Use only the network shown next to each crypto address.

## Development background

The application grew from practical UA FREE content operations rather than from a generic social-media demo. Development, review and test preparation were assisted by OpenAI ChatGPT using the GPT-5.6 Thinking model. Product decisions, credentials, editorial judgment and live publication validation remained under human control.

## License

GPL-2.0-or-later. See [LICENSE](LICENSE).
